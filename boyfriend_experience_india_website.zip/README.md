# Independent Male Companion Website — free setup

This is the Boyfriend Experience India static website plus a private email form handler. It contains no public phone number, public email address, or profile photo. It describes lawful adult social companionship, dates and travel, with day-based social companionship pricing discussed privately.

## Files
- `index.html` — website page
- `Code.gs` — Google Apps Script that forwards enquiries to your private email

## Important scope
The page is written for lawful adult social companionship (conversation, outings and travel company). It is not an advertisement or booking service for paid sexual acts. Only adults (18+) should submit enquiries. Follow applicable local laws and respect consent and privacy.

## Step 1 — Connect your private email form
1. Sign in to the Google account where you want to receive enquiries.
2. Open https://script.google.com/ and create a new project.
3. Replace the starter code with the contents of `Code.gs`.
4. In the first few lines, replace `REPLACE_WITH_YOUR_PRIVATE_EMAIL` with your email address. This address stays in the Apps Script project and is not printed on the public website.
5. Click **Deploy → New deployment**.
6. Select **Web app**.
7. Set **Execute as** to **Me**.
8. Set **Who has access** to **Anyone** (otherwise visitors may not be able to submit).
9. Deploy and authorize the script. Copy the Web app URL ending in `/exec`.

## Step 2 — Connect the website to the form
1. Open `index.html` in a text editor.
2. Find `PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE`.
3. Replace it with the Web app URL copied in Step 1.
4. Save the file.

## Step 3 — Publish free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com/.
2. Create a new **public** repository, for example `companion-profile`.
3. Upload `index.html` to the repository's root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**; select `main` and `/ (root)`, then Save.
6. GitHub will show the free site address, usually `https://YOUR-USERNAME.github.io/companion-profile/`.

You do not need to buy a domain to start. A custom domain can be considered later.

## Before sharing the website
- Test the form yourself and confirm the enquiry reaches your inbox.
- Keep the Apps Script project private.
- Do not ask visitors for identity documents, passwords, OTPs or payment-card details.
- Avoid collecting unnecessary personal information. Consider adding a privacy notice and reviewing applicable privacy and platform rules.
- Apps Script quotas and GitHub Pages terms apply; free services can change their limits or policies.
