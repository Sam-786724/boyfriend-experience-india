/*
  PRIVATE ENQUIRY HANDLER
  1. Replace OWNER_EMAIL with the email address that should receive enquiries.
  2. Deploy as a Web app: Execute as "Me"; Who has access: "Anyone".
  3. Copy the Web app URL into the form action in index.html.
  Keep this script private. Do not put the recipient email in the public website.
*/
const OWNER_EMAIL = "REPLACE_WITH_YOUR_PRIVATE_EMAIL";

function doPost(e) {
  const p = (e && e.parameter) ? e.parameter : {};

  // Basic spam trap: real visitors should leave this field empty.
  if (p.website) {
    return HtmlService.createHtmlOutput("Enquiry received.");
  }

  if (p.adultConfirmation !== "Yes" || p.privacyConsent !== "Yes") {
    return HtmlService.createHtmlOutput("Please confirm the required declarations.");
  }

  const nickname = clean(p.nickname, 80);
  const replyEmail = clean(p.replyEmail, 160);
  const city = clean(p.city, 100);
  const companionship = clean(p.companionship, 120);
  const preferredDate = clean(p.preferredDate, 40);
  const message = clean(p.message, 2000);

  if (!nickname || !replyEmail || !city || !companionship || !message) {
    return HtmlService.createHtmlOutput("Please complete all required fields.");
  }

  const subject = "New private companionship enquiry";
  const body =
    "A new website enquiry was submitted.\n\n" +
    "Name/nickname: " + nickname + "\n" +
    "Reply email: " + replyEmail + "\n" +
    "City: " + city + "\n" +
    "Enquiry type: " + companionship + "\n" +
    "Preferred date: " + (preferredDate || "Not specified") + "\n\n" +
    "Message:\n" + message + "\n\n" +
    "Adult confirmation: Yes\nPrivacy consent: Yes";

  MailApp.sendEmail({
    to: OWNER_EMAIL,
    subject: subject,
    body: body,
    replyTo: replyEmail
  });

  return HtmlService.createHtmlOutput(
    "<p>Thank you. Your enquiry has been submitted. If a reply is appropriate, it will be sent to the email address you provided.</p>"
  );
}

function clean(value, maxLength) {
  return String(value || "").replace(/[<>]/g, "").trim().slice(0, maxLength);
}
